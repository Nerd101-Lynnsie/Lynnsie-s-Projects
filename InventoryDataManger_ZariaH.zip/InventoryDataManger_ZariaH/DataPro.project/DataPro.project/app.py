#Zaria Hill - 03/24/2026 - Python Inventory Manager
#Create a program that collects and stores a businesses inventory info then reports what products to order

'''
PLEASE READ BEFORE RUNNING PROGRAM

copy into terminal command prompt: python -m pip install requests flask
'''

import os
import csv
import requests
from flask import Flask, render_template, request
from datetime import datetime
from collections import defaultdict


app = Flask(__name__)

#Pull product info from API
def get_products():
    url = "https://fakestoreapi.com/products"
    response = requests.get(url)
    
    print("Status code:", response.status_code)
    print("Response text:", response.text)
    
    return response.json()
    
#Determine ideal amount of items should be in inventory
def get_ideal_stock(price):
    if price < 20:
        return 30
    elif price < 50:
        return 20
    else:
        return 10

#Analyze Inventory
def analyze_inventory(products, inventory):
    report = []

    for product in products:
        name = product["title"]
        price = product["price"]

        current = int(inventory.get(name, 0))
        ideal = get_ideal_stock(price)
        to_order = max(0, ideal - current)

        report.append({
            "id": product["id"],
            "name": name,
            "price": product["price"],
            "description": product["description"],
            "image": product["image"],
            "current": current,
            "ideal": ideal,
            "to_order": to_order
        })

    return report

#Move old report to history before creating new one
def rotate_inventory_report():
    os.makedirs("history", exist_ok=True)

    if os.path.exists("inventory_report.csv"):

        # Create timestamped history filename
        timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")

        new_name = f"history/inventory_{timestamp}.csv"

        os.rename("inventory_report.csv", new_name)

        print(f"Previous report saved as {new_name}")

#CSV Storage (Long term storage)
def save_inventory_report(report):
    with open("inventory_report.csv", "w", newline="") as file:
        writer = csv.writer(file)

        writer.writerow([
            "Product",
            "Current Stock",
            "Ideal Stock",
            "Order Amount"
        ])

        for item in report:
            writer.writerow([
                item["name"],
                item["current"],
                item["ideal"],
                item["to_order"]
            ])

#Load CSV Inventory info
def load_previous_inventory():
    inventory = {}

    if not os.path.exists("inventory_report.csv"):
        return inventory

    with open("inventory_report.csv", newline="") as file:
        reader = csv.DictReader(file)

        for row in reader:
            inventory[row["Product"]] = row["Current Stock"]

    return inventory

#TIMESTAMP SAVING
def save_inventory_history(report):
    timestamp = datetime.now().strftime("%Y-%m-%d %H:%M:%S")

    with open("inventory_history.csv", "a", newline="") as file:
        writer = csv.writer(file)

        for item in report:
            writer.writerow([
                timestamp,
                item["name"],
                item["current"],
                item["ideal"],
                item["to_order"]
            ])


#ROUTES
#home
@app.route("/")
def home():
    products = get_products()
    previous_inventory = load_previous_inventory()
    
    return render_template("index.html", products=products, previous_inventory=previous_inventory)

#inventory
@app.route("/inventory", methods=["POST"])
def inventory():
    products = get_products()

    inventory_data = {}
    for product in products:
        name = product["title"]
        inventory_data[name] = request.form.get(name, 0)

    report = analyze_inventory(products, inventory_data)

    rotate_inventory_report()
    save_inventory_report(report)
    save_inventory_history(report)

    return render_template("inventory.html", report=report)

#Order Num/Product ID
@app.route("/order/<int:product_id>")
def order(product_id):

    products = get_products()
    previous_inventory = load_previous_inventory()

    selected_product = None
    to_order = 0

    for product in products:
        if product["id"] == product_id:
            selected_product = product

            current = int(previous_inventory.get(product["title"], 0))
            ideal = get_ideal_stock(product["price"])
            to_order = max(0, ideal - current)

            break

    return render_template(
        "order.html",
        product=selected_product,
        to_order=to_order
    )

#past reports - list all saved history files
@app.route("/past-reports")
def past_reports():
    os.makedirs("history", exist_ok=True)
    files = []

    for f in sorted(os.listdir("history"), reverse=True):
        if f.endswith(".csv"):
            try:
                parts = f.replace("inventory_", "").replace(".csv", "")
                dt = datetime.strptime(parts, "%Y%m%d_%H%M%S")
                display = dt.strftime("%B %d, %Y at %I:%M:%S %p")
            except:
                display = f

            files.append({"filename": f, "display": display})

    return render_template("past_reports.html", files=files)

#past reports - view a single report
@app.route("/past-reports/<filename>")
def view_report(filename):
    filepath = os.path.join("history", filename)
    report = []

    if os.path.exists(filepath):
        with open(filepath, newline="") as file:
            reader = csv.DictReader(file)
            for row in reader:
                report.append(row)

    try:
        parts = filename.replace("inventory_", "").replace(".csv", "")
        dt = datetime.strptime(parts, "%Y%m%d_%H%M%S")
        display = dt.strftime("%B %d, %Y at %I:%M:%S %p")
    except:
        display = filename

    return render_template("view_report.html", report=report, filename=filename, display=display)

#demo landing page
@app.route("/demo")
def demo():
    return render_template("demolandingpage.html")

#Run Program
if __name__ == "__main__":
    app.run(debug=True)